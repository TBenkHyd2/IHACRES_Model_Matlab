close all; clc; clear all; % 
%  COMPILATION OF MODIFIED IHACRES RAINFALL-RUNOFF MODEL BY TARIK BENKACI & N. DECHEMI (SCEUA) OF (IHACRES-VERSION.PERRIN 2000) 
% data=load('File_Data.txt'); % File of Data, do not change Name of this File, only copy and paste your Data
Optim_IHACRES
% P = data(:,1);  % First Vector : Rainfall in mm
% E = data(:,2);  % Second Vector : Evapotranspiration in mm
% Qobs=data(:,3); % Third Vector of Data  in m3/s
% param=load('parameters.txt'); % Paremters of Calibration
% Sup=param(1);  %Area of Basin in km2
%  Bounds of Parameters : in File :   Bounds_Param.txt  
% Bounds=load('Bounds_Param.txt)
%bl=Bounds(1:6)';
%bu=Bounds(7:12)';
% x0=load('Initial_Param.txt'); x0= x0' 
% Dr T.B
 

 
