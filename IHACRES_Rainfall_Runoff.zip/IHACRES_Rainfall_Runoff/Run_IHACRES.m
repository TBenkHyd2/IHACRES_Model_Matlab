close all; clc; clear all; % 
%  COMPILATION OF MODIFIED IHACRES RAINFALL-RUNOFF (IHAC6) BY TARIK BENKACI & N. DECHEMI (OPT :SCEUA) 
% The version used : Oudin et al., 2005
% data=load('File_Data.txt'); % File of Data, do not change Name of this File, only copy and paste your Data
Optim_IHACRES
% P = data(:,1);  % First Vector : Rainfall in mm
% E = data(:,2);  % Second Vector : Evapotranspiration in mm
% Qobs=data(:,3); % Third Vector of Data  in m3/s
% param=load('parameters.txt'); % Paremters of Calibration
% Sup=param(1);  %Area of Basin in km2
%  Bounds of Parameters : in File :   Bounds_Param.txt: Bounds=load('Bounds_Param.txt)
  %bl=Bounds(1:6)'; Lower Bounds
  %bu=Bounds(7:12)'; Upper Bounds
% x0=load('Initial_Param.txt'); x0= x0' (the Values are optioannal Not important: Stochasic optimisation)
%   Dr T.B (2021).
 

 
